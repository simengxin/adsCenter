package com.cmcm.adsCenter.module.triggerInfo.task;

import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import java.io.*;

@Controller
public class testHttp {

    @RequestMapping(value="/testHttp")
    public void test(HttpServletRequest request) throws IOException {
        BufferedReader br = request.getReader();

        String str, wholeStr = "";
        while((str = br.readLine()) != null){
            wholeStr += str;
        }
        System.out.println("post_data:"+wholeStr);
        try{
            PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(new File("D:/receive_ad.info"))));
            writer.write(str);
            writer.close();
        }catch(IOException ex){
            ex.printStackTrace();
        }
    }
}
