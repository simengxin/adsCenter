package com.cmcm.adsCenter.module.triggerInfo.domain;

public class TriggerInfo {
    private int ad_type;
    private int age;
    private int ext_posid;
    private int animation;//是否为爆款
    private int app_behaviour;//落地页类型
    private int app_type;//app类型 1游戏 2应用 3不限制
    private int bid_type;//计费类型 1cpi 2 cpt 3 cpc 4 cpm 5 cpv
    private String bindapp;//客户端使用场景app
    private String carrier;//运营商
    private String channel;//渠道
    private String user_id;

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public int getApp_type() {
        return app_type;
    }

    public void setApp_type(int app_type) {
        this.app_type = app_type;
    }

    public int getBid_type() {
        return bid_type;
    }

    public void setBid_type(int bid_type) {
        this.bid_type = bid_type;
    }

    public String getBindapp() {
        return bindapp;
    }

    public void setBindapp(String bindapp) {
        this.bindapp = bindapp;
    }

    public String getCarrier() {
        return carrier;
    }

    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public int getApp_behaviour() {
        return app_behaviour;
    }

    public void setApp_behaviour(int app_behaviour) {
        this.app_behaviour = app_behaviour;
    }

    public int getAnimation() {
        return animation;
    }

    public void setAnimation(int animation) {
        this.animation = animation;
    }

    public int getExt_posid() {
        return ext_posid;
    }

    public void setExt_posid(int ext_posid) {
        this.ext_posid = ext_posid;
    }

    public int getAd_type() {
        return ad_type;
    }

    public void setAd_type(int ad_type) {
        this.ad_type = ad_type;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
