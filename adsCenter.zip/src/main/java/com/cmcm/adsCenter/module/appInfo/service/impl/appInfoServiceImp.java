package com.cmcm.adsCenter.module.appInfo.service.impl;

import com.cmcm.adsCenter.module.appInfo.dao.appInfoDao;
import com.cmcm.adsCenter.module.appInfo.domain.AppInfo;
import com.cmcm.adsCenter.module.appInfo.service.appInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("appInfoServiceImp")
public class appInfoServiceImp implements appInfoService {
    @Autowired
    private appInfoDao dao;

    @Override
    public AppInfo getby(String identity_id) {
        return dao.selectByPrimaryKey(identity_id);
    }

    @Override
    public List<AppInfo> findAll() {
        return dao.findAll();
    }

    @Override
    public int save(AppInfo info) {
        return dao.insert(info);
    }
}
