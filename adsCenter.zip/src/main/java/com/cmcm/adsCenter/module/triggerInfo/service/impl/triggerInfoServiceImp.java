package com.cmcm.adsCenter.module.triggerInfo.service.impl;

import com.cmcm.adsCenter.module.triggerInfo.dao.triggerInfoDao;
import com.cmcm.adsCenter.module.triggerInfo.domain.TriggerInfo;
import com.cmcm.adsCenter.module.triggerInfo.service.triggerInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service("triggerInfoServiceImp")
public class triggerInfoServiceImp implements triggerInfoService {
    @Autowired
    private triggerInfoDao triggerdao;
    @Override
    public TriggerInfo getby(String identity_id) {
        return triggerdao.selectByPrimaryKey(identity_id);
    }

    @Override
    public List<TriggerInfo> findAll() {
        return triggerdao.findAll();
    }

    @Override
    public int save(TriggerInfo info) {
        return triggerdao.insert(info);
    }
}
