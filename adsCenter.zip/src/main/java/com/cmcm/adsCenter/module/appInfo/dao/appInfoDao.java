package com.cmcm.adsCenter.module.appInfo.dao;

import com.cmcm.adsCenter.module.appInfo.domain.AppInfo;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface appInfoDao {
    AppInfo selectByPrimaryKey(String key);
    List<AppInfo> findAll();
    int insert(AppInfo info);
}
