package com.cmcm.adsCenter.module.triggerInfo.service;

import com.cmcm.adsCenter.module.triggerInfo.domain.TriggerInfo;

import java.util.List;

public interface triggerInfoService {
    TriggerInfo getby(String identity_id);
    List<TriggerInfo> findAll();
    int save(TriggerInfo info);
}
