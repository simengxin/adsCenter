package com.cmcm.adsCenter.module.appInfo.controller;

import com.alibaba.fastjson.JSON;
import com.cmcm.adsCenter.module.appInfo.domain.AppInfo;
import com.cmcm.adsCenter.module.appInfo.service.impl.appInfoServiceImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.cmcm.adsCenter.module.appInfo.service.appInfoService;

import javax.annotation.Resource;

@Controller
public class appInfoController {
    //@Resource(name="appInfoServiceImp")
    @Autowired
    private appInfoServiceImp service;
    @RequestMapping(value="/appInfo")
    public String appInfoPage(){
        return "appInfoPage";
    }
    @RequestMapping(value="/addAppInfo",method = RequestMethod.POST)
    public String addAppInfo(AppInfo app){
        String app_str = JSON.toJSONString(app);
        service.save(app);
        System.out.println(app_str);
        return "index";
    }
}
