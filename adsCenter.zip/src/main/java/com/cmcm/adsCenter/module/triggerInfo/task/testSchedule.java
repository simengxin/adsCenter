package com.cmcm.adsCenter.module.triggerInfo.task;

import com.alibaba.fastjson.JSON;
import com.cmcm.adsCenter.module.appInfo.domain.AppInfo;
import com.cmcm.adsCenter.module.appInfo.service.appInfoService;
import com.cmcm.adsCenter.module.triggerInfo.domain.TriggerInfo;
import com.cmcm.adsCenter.module.triggerInfo.service.triggerInfoService;
import com.cmcm.adsCenter.module.utils.HttpUtil.httpUtil;
import com.github.fracpete.processoutput4j.output.CollectingProcessOutput;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import com.github.fracpete.processoutput4j.output.ConsoleOutputProcessOutput;
import com.github.fracpete.rsync4j.RSync;
import javax.annotation.Resource;
import java.io.*;
import java.util.List;

@Component
public class testSchedule {
    @Resource(name="triggerInfoServiceImp")
    private triggerInfoService trigger_service;
    @Resource(name="appInfoServiceImp")
    private appInfoService app_service;
    @Scheduled(cron="0/30 * * * * ?")
    public void test() throws Exception {
       List<TriggerInfo> infos = trigger_service.findAll();
       String trigger_str = JSON.toJSONString(infos);
       List<AppInfo> apps = app_service.findAll();
       String app_str = JSON.toJSONString(apps);
       trigger_str = "{ \"Trigger\":" +trigger_str;
       app_str = "," + "\"AppInfo\":" + app_str + "}";
       String str = trigger_str + app_str;
       System.out.println(str);
        try{
            PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(new File("D:/generate_ad.info"))));
            writer.write(str);
            writer.close();
        }catch(IOException ex){
            ex.printStackTrace();
        }
        String src = "D:/generate_ad.info";
        String dest = "D:/软件下载";
        int code = rsync_file(src,dest);

//       String url = "http://localhost:8080/testHttp";
//       String res = httpUtil.postJson(url,str);
//       System.out.println(res);
    }
    public int rsync_file(String src,String dest) throws Exception {
        RSync rsync = new RSync()
                .source(src)
                .destination(dest)
                .recursive(true);
        CollectingProcessOutput output = rsync.execute();
        System.out.println(output.getStdOut());
        System.out.println("Exit code: " + output.getExitCode());
        if (output.getExitCode() > 0)
            System.err.println(output.getStdErr());
        return output.getExitCode();
    }
}
