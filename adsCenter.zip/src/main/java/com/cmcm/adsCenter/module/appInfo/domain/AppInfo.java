package com.cmcm.adsCenter.module.appInfo.domain;

public class AppInfo {
    private String big_pic;
    private String bname;//brand name
    private String button_id;
    private String button_txt;
    private String flow_perc;
    private String h5_ad_type;
    private String html_content;
    private String icon_url;
    private String idea_ct;
    private String idea_desc;
    private String idea_mt;
    private String is_lbs;
    private String is_richtext;
    private String is_top;
    private String lp_url;
    private String se_lan;
    private String title;
    private String unit_price;
    private String user_id;

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getBig_pic() {
        return big_pic;
    }

    public void setBig_pic(String big_pic) {
        this.big_pic = big_pic;
    }

    public String getBname() {
        return bname;
    }

    public void setBname(String bname) {
        this.bname = bname;
    }

    public String getButton_id() {
        return button_id;
    }

    public void setButton_id(String button_id) {
        this.button_id = button_id;
    }

    public String getButton_txt() {
        return button_txt;
    }

    public void setButton_txt(String button_txt) {
        this.button_txt = button_txt;
    }

    public String getFlow_perc() {
        return flow_perc;
    }

    public void setFlow_perc(String flow_perc) {
        this.flow_perc = flow_perc;
    }

    public String getH5_ad_type() {
        return h5_ad_type;
    }

    public void setH5_ad_type(String h5_ad_type) {
        this.h5_ad_type = h5_ad_type;
    }

    public String getHtml_content() {
        return html_content;
    }

    public void setHtml_content(String html_content) {
        this.html_content = html_content;
    }

    public String getIcon_url() {
        return icon_url;
    }

    public void setIcon_url(String icon_url) {
        this.icon_url = icon_url;
    }

    public String getIdea_ct() {
        return idea_ct;
    }

    public void setIdea_ct(String idea_ct) {
        this.idea_ct = idea_ct;
    }

    public String getIdea_desc() {
        return idea_desc;
    }

    public void setIdea_desc(String idea_desc) {
        this.idea_desc = idea_desc;
    }

    public String getIdea_mt() {
        return idea_mt;
    }

    public void setIdea_mt(String idea_mt) {
        this.idea_mt = idea_mt;
    }

    public String getIs_lbs() {
        return is_lbs;
    }

    public void setIs_lbs(String is_lbs) {
        this.is_lbs = is_lbs;
    }

    public String getIs_richtext() {
        return is_richtext;
    }

    public void setIs_richtext(String is_richtext) {
        this.is_richtext = is_richtext;
    }

    public String getIs_top() {
        return is_top;
    }

    public void setIs_top(String is_top) {
        this.is_top = is_top;
    }

    public String getLp_url() {
        return lp_url;
    }

    public void setLp_url(String lp_url) {
        this.lp_url = lp_url;
    }

    public String getSe_lan() {
        return se_lan;
    }

    public void setSe_lan(String se_lan) {
        this.se_lan = se_lan;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUnit_price() {
        return unit_price;
    }

    public void setUnit_price(String unit_price) {
        this.unit_price = unit_price;
    }
}
