package com.cmcm.adsCenter.module.triggerInfo.controller;

import com.alibaba.fastjson.JSON;
import com.cmcm.adsCenter.module.triggerInfo.domain.TriggerInfo;
import com.cmcm.adsCenter.module.triggerInfo.service.triggerInfoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.cmcm.adsCenter.module.appInfo.domain.AppInfo;
import org.springframework.web.bind.annotation.RequestParam;

import javax.annotation.Resource;
import java.util.List;

@Controller
public class TriggerInfoController {

    @Resource(name="triggerInfoServiceImp")
    private triggerInfoService trigger_service;
    @RequestMapping(value="/query")
    public String query_page(){
        return "query_trigger";
    }
    @RequestMapping(value="/show_query_info",method = RequestMethod.POST)
    public String show_query_info(@RequestParam("user_id") String user_id, Model model){
        if(user_id.isEmpty()){
            List<TriggerInfo> info = trigger_service.findAll();
        }
        TriggerInfo info = trigger_service.getby(user_id);
        model.addAttribute("trigger",info);
        String json_str = JSON.toJSONString(info);
        System.out.println(json_str);
        return "show_query_info";
    }
    @RequestMapping(value="/triggerInfo")
    public String triggerInfoPage(){
        return "triggerPage";
    }
    @RequestMapping(value="/addTriggerInfo",method = RequestMethod.POST)
    public String generate(TriggerInfo info){
        trigger_service.save(info);
        String jsonstr = JSON.toJSONString(info);
        System.out.println(jsonstr);
        return "index";
    }
}
