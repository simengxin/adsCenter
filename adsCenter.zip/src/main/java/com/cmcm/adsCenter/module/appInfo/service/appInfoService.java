package com.cmcm.adsCenter.module.appInfo.service;

import com.cmcm.adsCenter.module.appInfo.domain.AppInfo;

import java.util.List;

public interface appInfoService{
    AppInfo getby(String identity_id);
    List<AppInfo> findAll();
    int save(AppInfo info);
}