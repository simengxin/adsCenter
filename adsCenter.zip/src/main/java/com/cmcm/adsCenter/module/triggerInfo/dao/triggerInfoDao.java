package com.cmcm.adsCenter.module.triggerInfo.dao;

import com.cmcm.adsCenter.module.triggerInfo.domain.TriggerInfo;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface triggerInfoDao {
    TriggerInfo selectByPrimaryKey(String key);
    List<TriggerInfo> findAll();
    int insert(TriggerInfo trigger);
}
