import org.junit.Test;
import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;
import org.slf4j.LoggerFactory;

import java.util.Date;

import static org.quartz.JobBuilder.newJob;
import static org.quartz.TriggerBuilder.newTrigger;

public class HelloJob implements Job {
    private static org.slf4j.Logger logger = LoggerFactory.getLogger(HelloJob.class);
    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        System.out.println("hellojob" + new Date());
    }

    @Test
    public void test() throws SchedulerException {
        //创建调度器工厂
        SchedulerFactory schedFact = new StdSchedulerFactory();
        //利用工厂模式来构建一个调度器
        Scheduler sched = schedFact.getScheduler();
        //引入作业程序
        JobDetail job = newJob(HelloJob.class).withIdentity("myJob", "group1").build();
        long time = System.currentTimeMillis() +3*1000L;
        Date startTime = new Date(time);

        //创建trigger
        Trigger trigger = newTrigger().withDescription("this is a cronTrigger").withIdentity("jobtrigger","jobTriggerGroup")
                .startAt(startTime).withSchedule(CronScheduleBuilder.cronSchedule("0/2 * * * * ?")).build();
        sched.scheduleJob(job,trigger);
        sched.start();
        System.out.println("启动时间：" + new Date());
    }
}
