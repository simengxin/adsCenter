import com.cmcm.adsCenter.module.triggerInfo.dao.triggerInfoDao;
import com.cmcm.adsCenter.module.triggerInfo.domain.TriggerInfo;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;

import javax.annotation.Resource;

public class TestQuery {
    @Test
    public void query_key(){
        ApplicationContext ctx = new ClassPathXmlApplicationContext("mybatis/spring-mybatis.xml");
        triggerInfoDao dao =(triggerInfoDao) ctx.getBean(triggerInfoDao.class);
        TriggerInfo info = dao.selectByPrimaryKey("agent_tx");
        System.out.println(info.getBindapp());
    }
}
